// ─── Character Sets ────────────────────────────────────────────────────────

export const CHAR_SETS = {
  standard:     ' .:-=+*#%@',
  extended:     ' .\'`^",:;Il!i><~+_-?][}{1)(|\\tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$',
  block:        ' \u2591\u2592\u2593\u2588',
  minimal:      ' .oO0',
  braille:      ' \u2801\u2802\u2803\u2804\u2808\u280a\u280b\u280c\u2810\u2813\u2814\u2818\u281b\u281c\u2820\u2828\u2830\u2838\u2840\u2848\u2850\u2858\u2860\u2868\u2870\u2880\u2881\u2882\u2884\u2888\u2890\u2898\u28a0\u28a8\u28b0\u28b8\u28c0\u28c8\u28d0\u28d8\u28e0\u28e8\u28f0\u28f8',
  matrix:       ' .:=+*#MW&8%B@$',
  video2chars:  ' .-1+*abcdefghijklmnopqrstuvwxyz<>()/{}[?234567890ABCDEFGHIKLMNOPQRSTUVWXYZ%&@#$',
  letters:      ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
  numbers:      ' 0123456789',
  symbols:      ' .:+*#%$@&~=^/\\|!?[]{}()<>-',
  alphanumeric: ' 0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.:+*#%@',
  binary:       ' 01',
};

// ─── ANSI Colour Tables (shared with exporter) ─────────────────────────────

export const ANSI16 = [
  [0,0,0],[128,0,0],[0,128,0],[128,128,0],
  [0,0,128],[128,0,128],[0,128,128],[192,192,192],
  [128,128,128],[255,0,0],[0,255,0],[255,255,0],
  [0,0,255],[255,0,255],[0,255,255],[255,255,255],
];

// Precompute the full 256-colour palette for fast nearest-colour lookup
export const ANSI256 = (() => {
  const t = [];
  for (const c of ANSI16) t.push(c);
  const lvl = [0,95,135,175,215,255];
  for (let r = 0; r < 6; r++)
    for (let g = 0; g < 6; g++)
      for (let b = 0; b < 6; b++)
        t.push([lvl[r],lvl[g],lvl[b]]);
  for (let i = 0; i < 24; i++) { const v = 8 + i*10; t.push([v,v,v]); }
  return t;
})();

// ─── Colour Helpers ────────────────────────────────────────────────────────

export function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

export function closestRgb(palette, r, g, b) {
  let best = 0, bestD = Infinity;
  for (let i = 0; i < palette.length; i++) {
    const pr = palette[i][0], pg = palette[i][1], pb = palette[i][2];
    const d = (r-pr)**2 + (g-pg)**2 + (b-pb)**2;
    if (d < bestD) { bestD = d; best = i; }
  }
  return palette[best];
}

export function quantizeAnsi16(r, g, b) {
  let best = ANSI16[0], bestD = Infinity;
  for (let i = 0; i < 16; i++) {
    const c = ANSI16[i];
    const d = (r - c[0]) ** 2 + (g - c[1]) ** 2 + (b - c[2]) ** 2;
    if (d < bestD) { bestD = d; best = c; }
  }
  return best;
}

function quantizeCubeVal(v) {
  if (v < 48) return 0;
  if (v < 115) return 95;
  if (v < 155) return 135;
  if (v < 195) return 175;
  if (v < 235) return 215;
  return 255;
}

export function quantizeAnsi256(r, g, b) {
  const qr = quantizeCubeVal(r);
  const qg = quantizeCubeVal(g);
  const qb = quantizeCubeVal(b);
  const dCube = (r - qr) ** 2 + (g - qg) ** 2 + (b - qb) ** 2;
  const gray = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
  const grayStep = Math.max(0, Math.min(23, Math.round((gray - 8) / 10)));
  const qGray = 8 + grayStep * 10;
  const dGray = (r - qGray) ** 2 + (g - qGray) ** 2 + (b - qGray) ** 2;
  return dGray < dCube ? [qGray, qGray, qGray] : [qr, qg, qb];
}

// Build color lookup tables only when an ANSI export first needs them. This
// avoids several million distance checks and about 6 MiB of allocations at startup.
function buildAnsiLookupTable(palette) {
  const lut = new Uint8Array(32 * 32 * 32 * 3);
  for (let r = 0; r < 32; r++) {
    const vr = (r * 255 / 31) | 0;
    for (let g = 0; g < 32; g++) {
      const vg = (g * 255 / 31) | 0;
      for (let b = 0; b < 32; b++) {
        const vb = (b * 255 / 31) | 0;
        const [cr, cg, cb] = closestRgb(palette, vr, vg, vb);
        const idx = ((r << 10) | (g << 5) | b) * 3;
        lut[idx]     = cr;
        lut[idx + 1] = cg;
        lut[idx + 2] = cb;
      }
    }
  }
  return lut;
}

export let ANSI16_LUT = null;
export let ANSI256_LUT = null;

export function getAnsiColorLut(mode) {
  if (mode === 'ansi16') {
    if (!ANSI16_LUT) ANSI16_LUT = buildAnsiLookupTable(ANSI16);
    return ANSI16_LUT;
  }
  if (mode === 'ansi256') {
    if (!ANSI256_LUT) ANSI256_LUT = buildAnsiLookupTable(ANSI256);
    return ANSI256_LUT;
  }
  return null;
}

// ─── Image Adjustments ───────────────────────────────────────────────────────

export function adjustPixel(r, g, b, brightness, contrast, gamma, saturation) {
  if (brightness !== 0) {
    const d = brightness * 2.55;
    r += d; g += d; b += d;
  }

  if (contrast !== 0) {
    const f = (259 * (contrast + 255)) / (255 * (259 - contrast));
    r = f * (r - 128) + 128;
    g = f * (g - 128) + 128;
    b = f * (b - 128) + 128;
  }

  if (saturation !== 0) {
    const gray = 0.299*r + 0.587*g + 0.114*b;
    const s = (saturation + 100) / 100;
    r = gray + s*(r - gray);
    g = gray + s*(g - gray);
    b = gray + s*(b - gray);
  }

  if (gamma !== 0) {
    const gv = gamma > 0 ? 1/(1 + gamma/100) : 1 + Math.abs(gamma)/100;
    r = 255 * Math.pow(clamp(r)/255, gv);
    g = 255 * Math.pow(clamp(g)/255, gv);
    b = 255 * Math.pow(clamp(b)/255, gv);
  }

  return [clamp(r), clamp(g), clamp(b)];
}

const ESC = { '<':'&lt;', '>':'&gt;', '&':'&amp;', '"':'&quot;', "'":'&#39;' };
function esc(ch) { return ESC[ch] || ch; }

export function hexToRgbVec3(hex) {
  if (!hex || hex[0] !== '#') return [0.22, 1.0, 0.32];
  const r = parseInt(hex.slice(1, 3), 16) / 255.0;
  const g = parseInt(hex.slice(3, 5), 16) / 255.0;
  const b = parseInt(hex.slice(5, 7), 16) / 255.0;
  return [isNaN(r) ? 0.22 : r, isNaN(g) ? 1.0 : g, isNaN(b) ? 0.32 : b];
}

export function computeCropBox(vw, vh, aspect) {
  if (!aspect || aspect === 'auto') return { sx: 0, sy: 0, sw: vw, sh: vh };
  let targetRatio = 16 / 9;
  if (aspect === '9:16') targetRatio = 9 / 16;
  else if (aspect === '1:1') targetRatio = 1.0;
  else if (aspect === '4:3') targetRatio = 4 / 3;
  else if (aspect === '16:9') targetRatio = 16 / 9;

  const currentRatio = vw / vh;
  if (currentRatio > targetRatio) {
    const sw = Math.round(vh * targetRatio);
    const sx = Math.round((vw - sw) / 2);
    return { sx, sy: 0, sw, sh: vh };
  } else {
    const sh = Math.round(vw / targetRatio);
    const sy = Math.round((vh - sh) / 2);
    return { sx: 0, sy, sw: vw, sh };
  }
}

export const BAYER_4X4 = [
   0,  8,  2, 10,
  12,  4, 14,  6,
   3, 11,  1,  9,
  15,  7, 13,  5
];

export function applyDithering(lumGrid, cols, rows, numLevels, mode = 'none') {
  if (!mode || mode === 'none' || numLevels <= 1) return;

  if (mode === 'bayer') {
    const spread = 1.0 / (numLevels - 1);
    for (let r = 0; r < rows; r++) {
      const rOffset = r * cols;
      const bRow = (r % 4) * 4;
      for (let c = 0; c < cols; c++) {
        const bVal = (BAYER_4X4[bRow + (c % 4)] / 16.0 - 0.46875) * spread;
        const idx = rOffset + c;
        const v = lumGrid[idx] + bVal;
        lumGrid[idx] = v < 0 ? 0 : v > 1 ? 1 : v;
      }
    }
    return;
  }

  if (mode === 'floyd') {
    const step = 1.0 / (numLevels - 1);
    for (let r = 0; r < rows; r++) {
      const rOffset = r * cols;
      const nextROffset = (r + 1) * cols;
      const hasNextR = r + 1 < rows;
      for (let c = 0; c < cols; c++) {
        const idx = rOffset + c;
        const oldVal = lumGrid[idx];
        const quantIdx = Math.round(oldVal / step);
        const newVal = Math.min(1.0, Math.max(0.0, quantIdx * step));
        const err = oldVal - newVal;
        lumGrid[idx] = newVal;

        if (c + 1 < cols) lumGrid[idx + 1] += err * (7 / 16);
        if (hasNextR) {
          if (c > 0) lumGrid[nextROffset + c - 1] += err * (3 / 16);
          lumGrid[nextROffset + c] += err * (5 / 16);
          if (c + 1 < cols) lumGrid[nextROffset + c + 1] += err * (1 / 16);
        }
      }
    }
    return;
  }

  if (mode === 'atkinson') {
    const step = 1.0 / (numLevels - 1);
    const div8 = 1 / 8;
    for (let r = 0; r < rows; r++) {
      const rOffset = r * cols;
      for (let c = 0; c < cols; c++) {
        const idx = rOffset + c;
        const oldVal = lumGrid[idx];
        const quantIdx = Math.round(oldVal / step);
        const newVal = Math.min(1.0, Math.max(0.0, quantIdx * step));
        const err = (oldVal - newVal) * div8;
        lumGrid[idx] = newVal;

        if (c + 1 < cols) lumGrid[idx + 1] += err;
        if (c + 2 < cols) lumGrid[idx + 2] += err;
        if (r + 1 < rows) {
          const nextR = (r + 1) * cols;
          if (c > 0) lumGrid[nextR + c - 1] += err;
          lumGrid[nextR + c] += err;
          if (c + 1 < cols) lumGrid[nextR + c + 1] += err;
        }
        if (r + 2 < rows) {
          lumGrid[(r + 2) * cols + c] += err;
        }
      }
    }
  }
}

export function getGraphicsProfile() {
  const canvas = typeof document !== 'undefined' ? document.createElement('canvas') : null;
  const gl = canvas ? (canvas.getContext('webgl2') || canvas.getContext('webgl')) : null;
  const userAgent = typeof navigator !== 'undefined' ? (navigator.userAgent || '') : '';
  const mobile = /Android|iPhone|iPad|Mobile/i.test(userAgent);
  const hardwareConcurrency = typeof navigator !== 'undefined' && typeof navigator.hardwareConcurrency === 'number'
    ? navigator.hardwareConcurrency
    : 4;

  let quality = 'high';
  let maxTextureSize = 0;
  if (!gl) {
    quality = 'fallback';
  } else {
    maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    if (mobile || hardwareConcurrency <= 4 || maxTextureSize < 4096) quality = 'balanced';
    if (hardwareConcurrency <= 2 || maxTextureSize < 2048) quality = 'low';
  }

  const profile = {
    hasWebGL: !!gl,
    quality,
    renderer: gl ? (gl.getParameter(gl.RENDERER) || 'unknown') : 'none',
    vendor: gl ? (gl.getParameter(gl.VENDOR) || 'unknown') : 'none',
    maxTextureSize,
    hardwareConcurrency,
    mobile,
  };
  gl?.getExtension('WEBGL_lose_context')?.loseContext();
  return profile;
}

// ─── Character Glyph Atlas (256 Glyphs Offscreen Texture) ────────────────────

export class AsciliGlyphAtlas {
  constructor() {
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    this.cellW = 16;
    this.cellH = 28;
    this.cols = 16;
    this.rows = 16;
    this.canvas.width = this.cellW * this.cols;  // 256
    this.canvas.height = this.cellH * this.rows; // 448
    this.charMap = [];
    this.charToIdx = new Map();
    this.charCount = 0;
    this.lastCharSetKey = '';
    this.version = 0;
  }

  update(charSet) {
    const key = (typeof charSet === 'string') ? charSet : (Array.isArray(charSet) ? charSet.join('') : '');
    if (key === this.lastCharSetKey && this.charMap.length > 0) return false;
    this.lastCharSetKey = key;

    const chars = Array.from(key && key.length > 0 ? key : ' .:-=+*#%@');
    this.charCount = chars.length;
    const allChars = [...chars];
    const edgeChars = ['-', '|', '/', '\\', ' '];
    for (const ec of edgeChars) {
      if (!allChars.includes(ec)) allChars.push(ec);
    }

    this.charMap = allChars;
    this.charToIdx.clear();
    for (let i = 0; i < allChars.length; i++) {
      this.charToIdx.set(allChars[i], i);
    }

    const { ctx, canvas, cellW, cellH, cols } = this;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.round(cellH * 0.72)}px "Courier New", monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    for (let i = 0; i < allChars.length; i++) {
      const ch = allChars[i];
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = col * cellW + cellW * 0.5;
      const y = row * cellH + cellH * 0.5;
      ctx.fillText(ch, x, y);
    }

    this.version++;
    return true;
  }

  getRampData(invertChars = false) {
    const ramp = new Uint8Array(256);
    const n = this.charCount;
    if (n <= 0) return ramp;
    for (let i = 0; i < 256; i++) {
      const lum = i / 255.0;
      let ci = (lum * (n - 1) + 0.5) | 0;
      if (ci >= n) ci = n - 1;
      else if (ci < 0) ci = 0;
      if (invertChars) ci = (n - 1) - ci;
      ramp[i] = ci;
    }
    return ramp;
  }
}

// ─── GPU WebGL Fragment Shader ──────────────────────────────────────────────

const VS_SRC = `
attribute vec2 a_pos;
varying vec2 v_uv;
void main() {
  v_uv = (a_pos + 1.0) * 0.5;
  v_uv.y = 1.0 - v_uv.y;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`;

const FS_SRC = `
precision mediump float;
varying vec2 v_uv;

uniform sampler2D u_video;
uniform sampler2D u_atlas;
uniform sampler2D u_ramp;

uniform vec2  u_gridSize;
uniform vec2  u_atlasGrid;
uniform int   u_colorMode;
uniform vec3  u_monoColor;
uniform int   u_scanlines;

uniform float u_brightness;
uniform float u_contrastMult;
uniform float u_gammaExp;
uniform float u_saturation;

uniform int   u_enableEdge;
uniform float u_edgeThresholdSq;
uniform float u_idxDash;
uniform float u_idxPipe;
uniform float u_idxSlash;
uniform float u_idxBackslash;

uniform int   u_mirror;
uniform int   u_ditherMode;
uniform vec4  u_cropRect;
uniform float u_charCount;
uniform vec3  u_bgColor;

uniform sampler2D u_mask;
uniform int   u_hasMask;
uniform int   u_renderMode;
uniform float u_maskThreshold;
uniform float u_maskFeather;
uniform float u_bgBrightness;
uniform float u_bgContrast;
uniform float u_bgCharAnimOffset;
uniform sampler2D u_fgRamp;
uniform float u_fgCharCount;

vec3 adjustColor(vec3 c) {
  if (u_brightness != 0.0) {
    c += u_brightness;
  }
  if (u_contrastMult != 1.0) {
    c = (c - 0.5) * u_contrastMult + 0.5;
  }
  if (u_saturation != 0.0) {
    float gray = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(gray), c, 1.0 + u_saturation);
  }
  if (u_gammaExp != 1.0) {
    c = pow(clamp(c, 0.0, 1.0), vec3(u_gammaExp));
  }
  return clamp(c, 0.0, 1.0);
}

void main() {
  vec2 coord = v_uv;
  if (u_mirror == 1) {
    coord.x = 1.0 - coord.x;
  }

  vec2 cellCoord  = coord * u_gridSize;
  vec2 cellIndex  = floor(cellCoord);
  vec2 inCell     = fract(cellCoord);

  vec2 normCenter = (cellIndex + 0.5) / u_gridSize;
  vec2 sampleCenter = u_cropRect.xy + normCenter * u_cropRect.zw;
  vec3 rawRgb     = texture2D(u_video, sampleCenter).rgb;
  vec3 rgb        = adjustColor(rawRgb);
  float lum       = dot(rgb, vec3(0.299, 0.587, 0.114));

  float maskVal = 0.0;
  if (u_hasMask == 1) {
    maskVal = texture2D(u_mask, sampleCenter).r;
  }
  float isSubject = smoothstep(u_maskThreshold - u_maskFeather, u_maskThreshold + u_maskFeather, maskVal);

  if (u_renderMode == 1) {
    // Negative Space Mode: Detected subject remains completely empty & black
    if (isSubject >= 0.5) {
      gl_FragColor = vec4(u_bgColor, 1.0);
      return;
    }
  } else if (u_renderMode == 2) {
    // Inverted ASCII Mode: Detected subject rendered in ASCII, background empty
    if (isSubject < 0.5) {
      gl_FragColor = vec4(u_bgColor, 1.0);
      return;
    }
  }

  // Background specific adjustments for Negative Space or background regions in Hybrid
  if (u_renderMode == 1 || (u_renderMode == 3 && isSubject < 0.5)) {
    if (u_bgBrightness != 0.0) {
      rgb += u_bgBrightness;
    }
    if (u_bgContrast != 0.0) {
      rgb = (rgb - 0.5) * (1.0 + u_bgContrast) + 0.5;
    }
    rgb = clamp(rgb, 0.0, 1.0);
    lum = dot(rgb, vec3(0.299, 0.587, 0.114));
  }

  if (u_ditherMode == 1) {
    vec2 b = mod(cellIndex, 4.0);
    float bIdx = b.y * 4.0 + b.x;
    float bVal = 0.0;
    if (bIdx < 4.0) {
      if (bIdx < 1.0) bVal = 0.0; else if (bIdx < 2.0) bVal = 8.0; else if (bIdx < 3.0) bVal = 2.0; else bVal = 10.0;
    } else if (bIdx < 8.0) {
      if (bIdx < 5.0) bVal = 12.0; else if (bIdx < 6.0) bVal = 4.0; else if (bIdx < 7.0) bVal = 14.0; else bVal = 6.0;
    } else if (bIdx < 12.0) {
      if (bIdx < 9.0) bVal = 3.0; else if (bIdx < 10.0) bVal = 11.0; else if (bIdx < 11.0) bVal = 1.0; else bVal = 9.0;
    } else {
      if (bIdx < 13.0) bVal = 15.0; else if (bIdx < 14.0) bVal = 7.0; else if (bIdx < 15.0) bVal = 13.0; else bVal = 5.0;
    }
    float spread = 1.0 / max(1.0, u_charCount - 1.0);
    lum = clamp(lum + (bVal / 16.0 - 0.46875) * spread, 0.0, 1.0);
  }

  float charIdx = -1.0;

  if (u_enableEdge == 1 && cellIndex.x > 0.0 && cellIndex.x < u_gridSize.x - 1.0 && cellIndex.y > 0.0 && cellIndex.y < u_gridSize.y - 1.0) {
    vec2 stepX = vec2(u_cropRect.z / u_gridSize.x, 0.0);
    vec2 stepY = vec2(0.0, u_cropRect.w / u_gridSize.y);

    float lumR = dot(texture2D(u_video, sampleCenter + stepX).rgb, vec3(0.299, 0.587, 0.114));
    float lumL = dot(texture2D(u_video, sampleCenter - stepX).rgb, vec3(0.299, 0.587, 0.114));
    float lumD = dot(texture2D(u_video, sampleCenter + stepY).rgb, vec3(0.299, 0.587, 0.114));
    float lumU = dot(texture2D(u_video, sampleCenter - stepY).rgb, vec3(0.299, 0.587, 0.114));

    float gx = (lumR - lumL) * 0.5;
    float gy = (lumD - lumU) * 0.5;
    float magSq = gx * gx + gy * gy;

    if (magSq >= u_edgeThresholdSq) {
      float absGx = abs(gx);
      float absGy = abs(gy);
      if (absGy > 1.8 * absGx) {
        charIdx = u_idxDash;
      } else if (absGx > 1.8 * absGy) {
        charIdx = u_idxPipe;
      } else {
        charIdx = (gx * gy > 0.0) ? u_idxBackslash : u_idxSlash;
      }
    }
  }

  if (charIdx < 0.0) {
    if (u_renderMode == 3 && isSubject >= 0.5) {
      charIdx = floor(texture2D(u_fgRamp, vec2(lum, 0.5)).r * 255.0 + 0.5);
    } else {
      charIdx = floor(texture2D(u_ramp, vec2(lum, 0.5)).r * 255.0 + 0.5);
      if (u_bgCharAnimOffset > 0.0 && (u_renderMode == 1 || isSubject < 0.5)) {
        charIdx = mod(charIdx + u_bgCharAnimOffset, max(1.0, u_charCount));
      }
    }
  }

  float atlasCols = u_atlasGrid.x;
  float atlasCol  = mod(charIdx, atlasCols);
  float atlasRow  = floor(charIdx / atlasCols);
  vec2 atlasUV    = (vec2(atlasCol, atlasRow) + inCell) / u_atlasGrid;

  float glyphAlpha = texture2D(u_atlas, atlasUV).a;

  vec3 color = rgb;
  if (u_colorMode == 0) {
    color = u_monoColor;
  } else if (u_colorMode == 1) {
    color = vec3(lum);
  } else if (u_colorMode == 2) {
    color = floor(rgb * 2.0 + 0.5) / 2.0;
  } else if (u_colorMode == 3) {
    color = floor(rgb * 5.0 + 0.5) / 5.0;
  }

  vec3 finalColor = mix(u_bgColor, color, glyphAlpha);

  if (u_scanlines == 1) {
    float scan = sin(gl_FragCoord.y * 1.5) * 0.15;
    finalColor = max(vec3(0.0), finalColor - scan);
  }

  gl_FragColor = vec4(finalColor, 1.0);
}
`;

function createWebGL2ShaderSources() {
  const vertex = `#version 300 es\n${VS_SRC
    .replace(/\battribute\b/g, 'in')
    .replace(/\bvarying\b/g, 'out')}`;
  const fragment = `#version 300 es\n${FS_SRC
    .replace(/\bvarying\b/g, 'in')
    .replace(/\btexture2D\b/g, 'texture')
    .replace('precision mediump float;', 'precision mediump float;\nout vec4 fragColor;')
    .replace(/\bgl_FragColor\b/g, 'fragColor')}`;
  return { vertex, fragment };
}

export class AsciliWebGLRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.profile = null;
    this.gpuTimeMs = null;
    this.supported = false;

    this._onContextLost = (e) => {
      e.preventDefault();
      this.supported = false;
    };
    this._onContextRestored = () => {
      this._initGL();
    };

    if (this.canvas && typeof this.canvas.addEventListener === 'function') {
      this.canvas.addEventListener('webglcontextlost', this._onContextLost, false);
      this.canvas.addEventListener('webglcontextrestored', this._onContextRestored, false);
    }

    this._initGL();
  }

  _initGL() {
    const canvas = this.canvas;
    this.gl = canvas.getContext('webgl2', { preserveDrawingBuffer: true, antialias: false, alpha: false });
    this.isWebGL2 = Boolean(this.gl);
    this.gl ||= canvas.getContext('webgl', { preserveDrawingBuffer: true, antialias: false, alpha: false });
    this.supported = !!this.gl;
    if (!this.supported) return;

    const gl = this.gl;
    this._timerExt = gl.getExtension('EXT_disjoint_timer_query_webgl2') ||
      gl.getExtension('EXT_disjoint_timer_query');
    this._gpuQuery = null;
    this._gpuQueryActive = false;
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);

    const quadVertices = new Float32Array([
      -1, -1,
       1, -1,
      -1,  1,
       1,  1,
    ]);
    this._quadBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this._quadBuf);
    gl.bufferData(gl.ARRAY_BUFFER, quadVertices, gl.STATIC_DRAW);

    const shaders = this.isWebGL2 ? createWebGL2ShaderSources() : { vertex: VS_SRC, fragment: FS_SRC };
    this._program = this._createProgram(gl, shaders.vertex, shaders.fragment);
    if (!this._program) {
      this.supported = false;
      return;
    }

    this._aPos             = gl.getAttribLocation(this._program, 'a_pos');
    this._uVideo           = gl.getUniformLocation(this._program, 'u_video');
    this._uAtlas           = gl.getUniformLocation(this._program, 'u_atlas');
    this._uRamp            = gl.getUniformLocation(this._program, 'u_ramp');
    this._uGridSize        = gl.getUniformLocation(this._program, 'u_gridSize');
    this._uAtlasGrid       = gl.getUniformLocation(this._program, 'u_atlasGrid');
    this._uColorMode       = gl.getUniformLocation(this._program, 'u_colorMode');
    this._uMonoColor       = gl.getUniformLocation(this._program, 'u_monoColor');
    this._uScanlines       = gl.getUniformLocation(this._program, 'u_scanlines');

    this._uBrightness      = gl.getUniformLocation(this._program, 'u_brightness');
    this._uContrastMult    = gl.getUniformLocation(this._program, 'u_contrastMult');
    this._uGammaExp        = gl.getUniformLocation(this._program, 'u_gammaExp');
    this._uSaturation      = gl.getUniformLocation(this._program, 'u_saturation');

    this._uEnableEdge      = gl.getUniformLocation(this._program, 'u_enableEdge');
    this._uEdgeThresholdSq = gl.getUniformLocation(this._program, 'u_edgeThresholdSq');
    this._uIdxDash         = gl.getUniformLocation(this._program, 'u_idxDash');
    this._uIdxPipe         = gl.getUniformLocation(this._program, 'u_idxPipe');
    this._uIdxSlash        = gl.getUniformLocation(this._program, 'u_idxSlash');
    this._uIdxBackslash    = gl.getUniformLocation(this._program, 'u_idxBackslash');

    this._uMirror          = gl.getUniformLocation(this._program, 'u_mirror');
    this._uDitherMode      = gl.getUniformLocation(this._program, 'u_ditherMode');
    this._uCropRect        = gl.getUniformLocation(this._program, 'u_cropRect');
    this._uCharCount       = gl.getUniformLocation(this._program, 'u_charCount');
    this._uBgColor         = gl.getUniformLocation(this._program, 'u_bgColor');

    this._uMask            = gl.getUniformLocation(this._program, 'u_mask');
    this._uHasMask         = gl.getUniformLocation(this._program, 'u_hasMask');
    this._uRenderMode      = gl.getUniformLocation(this._program, 'u_renderMode');
    this._uMaskThreshold   = gl.getUniformLocation(this._program, 'u_maskThreshold');
    this._uMaskFeather     = gl.getUniformLocation(this._program, 'u_maskFeather');
    this._uBgBrightness    = gl.getUniformLocation(this._program, 'u_bgBrightness');
    this._uBgContrast      = gl.getUniformLocation(this._program, 'u_bgContrast');
    this._uBgCharAnimOffset= gl.getUniformLocation(this._program, 'u_bgCharAnimOffset');
    this._uFgRamp          = gl.getUniformLocation(this._program, 'u_fgRamp');
    this._uFgCharCount     = gl.getUniformLocation(this._program, 'u_fgCharCount');

    this._texVideo = gl.createTexture();
    this._texAtlas = gl.createTexture();
    this._texRamp  = gl.createTexture();
    this._texFgRamp= gl.createTexture();

    this._setupTexture(this._texVideo, gl.LINEAR);
    this._setupTexture(this._texAtlas, gl.LINEAR);
    this._setupTexture(this._texRamp,  gl.NEAREST);
    this._setupTexture(this._texFgRamp,gl.NEAREST);

    this._lastAtlasVer = -1;
    this._lastRampKey  = '';
    this._lastFgRampKey= '';
    this._lastVideoW   = 0;
    this._lastVideoH   = 0;
  }

  _setupTexture(tex, filter) {
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }

  _createProgram(gl, vsSrc, fsSrc) {
    const vs = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vs, vsSrc);
    gl.compileShader(vs);
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) return null;

    const fs = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fs, fsSrc);
    gl.compileShader(fs);
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) return null;

    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return null;
    return prog;
  }

  renderDirect(sourceEl, cols, rows, atlas, config) {
    const gl = this.gl;
    if (!gl || gl.isContextLost() || !this.supported) return false;

    if (sourceEl instanceof HTMLMediaElement && sourceEl.readyState < 2) {
      return false;
    }

    const vw = sourceEl.videoWidth || sourceEl.width || 0;
    const vh = sourceEl.videoHeight || sourceEl.height || 0;
    if (vw <= 0 || vh <= 0 || this.canvas.width <= 0 || this.canvas.height <= 0) {
      return false;
    }

    this._pollGpuTimer();
    this._beginGpuTimer();

    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.useProgram(this._program);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this._texVideo);
    if (this._lastVideoW !== vw || this._lastVideoH !== vh) {
      this._lastVideoW = vw;
      this._lastVideoH = vh;
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, vw, vh, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    }
    try {
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, sourceEl);
    } catch {
      try {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, sourceEl);
        this._lastVideoW = sourceEl.videoWidth || sourceEl.width || vw;
        this._lastVideoH = sourceEl.videoHeight || sourceEl.height || vh;
      } catch {
        this._endGpuTimer();
        return false;
      }
    }

    if (this._lastAtlasVer !== atlas.version) {
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, this._texAtlas);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlas.canvas);
      this._lastAtlasVer = atlas.version;
    }

    const rampKey = `${atlas.version}_${config.invertChars}`;
    if (this._lastRampKey !== rampKey) {
      const rampData = atlas.getRampData(config.invertChars);
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, this._texRamp);
      if (this.isWebGL2) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 256, 1, 0, gl.RED, gl.UNSIGNED_BYTE, rampData);
      } else {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, 256, 1, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, rampData);
      }
      this._lastRampKey = rampKey;
    }

    gl.uniform1i(this._uVideo, 0);
    gl.uniform1i(this._uAtlas, 1);
    gl.uniform1i(this._uRamp,  2);

    gl.uniform2f(this._uGridSize, cols, rows);
    gl.uniform2f(this._uAtlasGrid, atlas.cols, atlas.rows);

    const mode = config.colorMode === 'monochrome' ? 0
               : config.colorMode === 'grayscale'  ? 1
               : config.colorMode === 'ansi16'     ? 2
               : config.colorMode === 'ansi256'    ? 3
               : 4;
    gl.uniform1i(this._uColorMode, mode);

    const monoRgb = hexToRgbVec3(config.monoColor);
    gl.uniform3f(this._uMonoColor, monoRgb[0], monoRgb[1], monoRgb[2]);
    gl.uniform1i(this._uScanlines, config.scanlines ? 1 : 0);

    const bgRgb = hexToRgbVec3(config.bgColor || '#000000');
    if (this._uBgColor) {
      gl.uniform3f(this._uBgColor, bgRgb[0], bgRgb[1], bgRgb[2]);
    }

    const b = (config.brightness || 0) / 100.0;
    const cVal = ((config.contrast || 0) / 100.0) * 255.0;
    const cMult = (config.contrast || 0) !== 0 ? (259.0 * (cVal + 255.0)) / Math.max(0.001, (255.0 * (259.0 - cVal))) : 1.0;
    const gVal = (config.gamma || 0) / 100.0;
    const gExp = gVal !== 0 ? (gVal > 0 ? 1.0 / (1.0 + gVal) : 1.0 + Math.abs(gVal)) : 1.0;
    const s = (config.saturation || 0) / 100.0;

    gl.uniform1f(this._uBrightness,   b);
    gl.uniform1f(this._uContrastMult, cMult);
    gl.uniform1f(this._uGammaExp,     gExp);
    gl.uniform1f(this._uSaturation,   s);

    const quality = this.profile?.quality || 'high';
    const edgeEnabled = (config.enableEdgeDetection ?? true) &&
      quality !== 'low' &&
      cols * rows <= 350_000 && atlas.charCount >= 5 && rows > 2 && cols > 2;
    gl.uniform1i(this._uEnableEdge, edgeEnabled ? 1 : 0);
    const eth = config.edgeThreshold ?? 0.16;
    gl.uniform1f(this._uEdgeThresholdSq, eth * eth);

    gl.uniform1f(this._uIdxDash,      atlas.charToIdx.get('-') ?? 0);
    gl.uniform1f(this._uIdxPipe,      atlas.charToIdx.get('|') ?? 0);
    gl.uniform1f(this._uIdxSlash,     atlas.charToIdx.get('/') ?? 0);
    gl.uniform1f(this._uIdxBackslash, atlas.charToIdx.get('\\') ?? 0);

    gl.uniform1i(this._uMirror, config.mirror ? 1 : 0);
    gl.uniform1i(this._uDitherMode, config.dithering === 'bayer' ? 1 : 0);
    const crop = computeCropBox(vw, vh, config.aspectRatio);
    gl.uniform4f(this._uCropRect, crop.sx / vw, crop.sy / vh, crop.sw / vw, crop.sh / vh);
    gl.uniform1f(this._uCharCount, atlas.charCount || 10);

    // Negative Space / Subject Segmentation uniforms
    let renderModeInt = 0;
    const rMode = config.renderMode || config.negSpaceMode || 'none';
    if (rMode === 'negative_space') renderModeInt = 1;
    else if (rMode === 'inverted_ascii') renderModeInt = 2;
    else if (rMode === 'hybrid') renderModeInt = 3;

    gl.uniform1i(this._uRenderMode, renderModeInt);

    let hasMask = 0;
    if (config.detector && config.detector.enabled && renderModeInt > 0) {
      const maskTex = config.detector.updateGLTexture(gl);
      if (maskTex) {
        gl.activeTexture(gl.TEXTURE3);
        gl.bindTexture(gl.TEXTURE_2D, maskTex);
        gl.uniform1i(this._uMask, 3);
        hasMask = 1;
      }
    }
    gl.uniform1i(this._uHasMask, hasMask);

    const maskThresh = config.maskThreshold ?? config.negSpaceSensitivity ?? 0.5;
    const maskFeather = config.maskFeather ?? config.negSpaceFeather ?? 0.08;
    const bgBright = (config.bgBrightness ?? config.negSpaceBgBrightness ?? 0) / 100.0;
    const bgContr = (config.bgContrast ?? config.negSpaceBgContrast ?? 0) / 100.0;
    const bgAnimOff = (config.bgCharAnimOffset ?? 0);

    gl.uniform1f(this._uMaskThreshold, maskThresh);
    gl.uniform1f(this._uMaskFeather, maskFeather);
    gl.uniform1f(this._uBgBrightness, bgBright);
    gl.uniform1f(this._uBgContrast, bgContr);
    gl.uniform1f(this._uBgCharAnimOffset, bgAnimOff);

    if (renderModeInt === 3 && config.fgAtlas) {
      const fgRampKey = `${config.fgAtlas.version}_${config.invertChars}`;
      if (this._lastFgRampKey !== fgRampKey) {
        const fgRampData = config.fgAtlas.getRampData(config.invertChars);
        gl.activeTexture(gl.TEXTURE4);
        gl.bindTexture(gl.TEXTURE_2D, this._texFgRamp);
        if (this.isWebGL2) {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 256, 1, 0, gl.RED, gl.UNSIGNED_BYTE, fgRampData);
        } else {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, 256, 1, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, fgRampData);
        }
        this._lastFgRampKey = fgRampKey;
      }
      gl.uniform1i(this._uFgRamp, 4);
      gl.uniform1f(this._uFgCharCount, config.fgAtlas.charCount || 10);
    }

    gl.bindBuffer(gl.ARRAY_BUFFER, this._quadBuf);
    gl.enableVertexAttribArray(this._aPos);
    gl.vertexAttribPointer(this._aPos, 2, gl.FLOAT, false, 0, 0);

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    this._endGpuTimer();
    return true;
  }

  _beginGpuTimer() {
    if (!this._timerExt || this._gpuQuery) return;
    const gl = this.gl;
    try {
      if (typeof gl.createQuery === 'function') {
        this._gpuQuery = { query: gl.createQuery(), webgl2: true };
        gl.beginQuery(this._timerExt.TIME_ELAPSED_EXT, this._gpuQuery.query);
      } else {
        this._gpuQuery = { query: this._timerExt.createQueryEXT(), webgl2: false };
        this._timerExt.beginQueryEXT(this._timerExt.TIME_ELAPSED_EXT, this._gpuQuery.query);
      }
      this._gpuQueryActive = true;
    } catch { this._gpuQuery = null; this._gpuQueryActive = false; }
  }

  _endGpuTimer() {
    if (!this._gpuQuery || !this._gpuQueryActive) return;
    try {
      if (this._gpuQuery.webgl2) this.gl.endQuery(this._timerExt.TIME_ELAPSED_EXT);
      else this._timerExt.endQueryEXT(this._timerExt.TIME_ELAPSED_EXT);
      this._gpuQueryActive = false;
    } catch {
      this._deleteGpuQuery();
    }
  }

  _pollGpuTimer() {
    if (!this._gpuQuery) return;
    const { gl, _timerExt: ext } = this;
    try {
      const available = this._gpuQuery.webgl2
        ? gl.getQueryParameter(this._gpuQuery.query, gl.QUERY_RESULT_AVAILABLE)
        : ext.getQueryObjectEXT(this._gpuQuery.query, ext.QUERY_RESULT_AVAILABLE_EXT);
      if (!available) return;
      const disjoint = gl.getParameter(ext.GPU_DISJOINT_EXT);
      const nanoseconds = this._gpuQuery.webgl2
        ? gl.getQueryParameter(this._gpuQuery.query, gl.QUERY_RESULT)
        : ext.getQueryObjectEXT(this._gpuQuery.query, ext.QUERY_RESULT_EXT);
      if (!disjoint && Number.isFinite(nanoseconds)) this.gpuTimeMs = nanoseconds / 1e6;
    } catch { /* Timer queries are optional and may be unavailable on some GPUs. */ }
    this._deleteGpuQuery();
  }

  _deleteGpuQuery() {
    if (!this._gpuQuery) return;
    try {
      if (this._gpuQuery.webgl2) this.gl.deleteQuery(this._gpuQuery.query);
      else this._timerExt.deleteQueryEXT(this._gpuQuery.query);
    } catch { /* Context may have been lost. */ }
    this._gpuQuery = null;
    this._gpuQueryActive = false;
  }
}

// ─── High-Speed Canvas 2D Fallback Renderer ──────────────────────────────────

export class AsciliCanvas2DRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    if (!this.ctx) throw new Error('Canvas 2D is unavailable');
  }

  render(cols, rows, charGrid, colorGrid, atlas, isMono, monoColorHex, fontSize = 10, bgColor = '#000000') {
    const { ctx, canvas } = this;
    const charW = canvas.width > 0 && cols > 0 ? (canvas.width / cols) : (fontSize * 0.601);
    const charH = canvas.height > 0 && rows > 0 ? (canvas.height / rows) : fontSize;
    const fontPx = Math.max(1, Math.floor(charH * 0.95));

    ctx.fillStyle = bgColor || '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.font = `bold ${fontPx}px "Courier New", monospace`;
    ctx.textBaseline = 'top';

    const charMap = atlas.charMap;

    if (isMono) {
      ctx.fillStyle = monoColorHex;
      for (let r = 0; r < rows; r++) {
        let line = '';
        const offset = r * cols;
        for (let c = 0; c < cols; c++) {
          const val = charGrid[offset + c];
          line += typeof val === 'string' ? val : (charMap[val] || ' ');
        }
        ctx.fillText(line, 0, r * charH, canvas.width);
      }
    } else {
      for (let r = 0; r < rows; r++) {
        const offset = r * cols;
        let run = '';
        let runStart = 0;
        let lastR = -1, lastG = -1, lastB = -1;

        for (let c = 0; c < cols; c++) {
          const idx = offset + c;
          const p3  = idx * 3;
          const cr  = colorGrid[p3];
          const cg  = colorGrid[p3 + 1];
          const cb  = colorGrid[p3 + 2];
          const val = charGrid[idx];
          const ch  = typeof val === 'string' ? val : (charMap[val] || ' ');

          if (cr === lastR && cg === lastG && cb === lastB) {
            run += ch;
          } else {
            if (run.length > 0) {
              ctx.fillStyle = `rgb(${lastR},${lastG},${lastB})`;
              ctx.fillText(run, runStart * charW, r * charH, run.length * charW);
            }
            run = ch;
            runStart = c;
            lastR = cr;
            lastG = cg;
            lastB = cb;
          }
        }
        if (run.length > 0) {
          ctx.fillStyle = `rgb(${lastR},${lastG},${lastB})`;
          ctx.fillText(run, runStart * charW, r * charH, run.length * charW);
        }
      }
    }
    return true;
  }
}

class AsciliCanvasWorkerRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    if (!this.ctx) throw new Error('Canvas 2D is unavailable');
    this.busy = false;
    this.failed = !this.ctx;
    this.renderTimeMs = null;
    this.generation = 0;
    this.worker = new Worker(new URL('./canvas-renderer.worker.js', import.meta.url), { type: 'module' });
    this.worker.onmessage = ({ data }) => {
      if (data.generation !== this.generation) {
        data.bitmap?.close();
        return;
      }
      this.busy = false;
      if (data.error) this.failed = true;
      if (Number.isFinite(data.renderMs)) this.renderTimeMs = data.renderMs;
      if (data.bitmap) {
        this.ctx.drawImage(data.bitmap, 0, 0, this.canvas.width, this.canvas.height);
        data.bitmap.close();
      }
    };
    this.worker.onerror = () => { this.busy = false; this.failed = true; };
  }

  render(video, cols, rows, atlas, config) {
    if (this.failed || typeof createImageBitmap !== 'function') return false;
    if (video instanceof HTMLMediaElement && video.readyState < 2) return false;
    if (this.busy) return true;
    const generation = this.generation;
    this.busy = true;
    createImageBitmap(video).then((frame) => {
      if (!this.busy || generation !== this.generation) { frame.close(); return; }
      this._bitmapErrors = 0;
      this.worker.postMessage({
        frame, width: this.canvas.width, height: this.canvas.height,
        cols, rows, config, chars: atlas.charMap.slice(0, atlas.charCount), generation,
      }, [frame]);
    }).catch(() => {
      if (generation === this.generation) {
        this.busy = false;
        this._bitmapErrors = (this._bitmapErrors || 0) + 1;
        if (this._bitmapErrors > 25) {
          this.failed = true;
        }
      }
    });
    return true;
  }

  reset() {
    this.generation++;
    this.busy = false;
  }
}

// ─── Character Set Engines ──────────────────────────────────────────────────

export class BaseCharacterSetEngine {
  constructor(id, name, characters, options = {}) {
    this.id = id;
    this.name = name;
    this.characters = typeof characters === 'string' ? Array.from(characters) : [...characters];
    this.options = options;
    this.edgeChars = options.edgeChars || ['-', '|', '/', '\\', ' '];
    this.charMap = [...this.characters];
    for (const ec of this.edgeChars) {
      if (!this.charMap.includes(ec)) this.charMap.push(ec);
    }
    this.charToIdx = new Map();
    this.charMap.forEach((ch, idx) => this.charToIdx.set(ch, idx));
  }

  get length() {
    return this.characters.length;
  }

  get rawString() {
    return this.characters.join('');
  }

  getRampData(invertChars = false) {
    const ramp = new Uint8Array(256);
    const n = this.characters.length;
    if (n <= 0) return ramp;
    for (let i = 0; i < 256; i++) {
      const lum = i / 255.0;
      let ci = (lum * (n - 1) + 0.5) | 0;
      if (ci >= n) ci = n - 1;
      else if (ci < 0) ci = 0;
      if (invertChars) ci = (n - 1) - ci;
      ramp[i] = ci;
    }
    return ramp;
  }

  getCharForLuminance(lum, invert = false) {
    const n = this.characters.length;
    if (n === 0) return ' ';
    let ci = Math.round(lum * (n - 1));
    if (ci >= n) ci = n - 1;
    else if (ci < 0) ci = 0;
    if (invert) ci = (n - 1) - ci;
    return this.characters[ci] ?? ' ';
  }

  getCharIndexForLuminance(lum, invert = false) {
    const n = this.characters.length;
    if (n <= 0) return 0;
    let ci = (lum * (n - 1) + 0.5) | 0;
    if (ci >= n) ci = n - 1;
    else if (ci < 0) ci = 0;
    if (invert) ci = (n - 1) - ci;
    return ci;
  }

  getEdgeChar(gx, gy) {
    const absGx = Math.abs(gx);
    const absGy = Math.abs(gy);
    if (absGy > 1.8 * absGx) return '-';
    if (absGx > 1.8 * absGy) return '|';
    return (gx * gy > 0) ? '\\' : '/';
  }
}

export class StandardCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('standard', 'Standard ASCII Ramp', CHAR_SETS.standard);
  }
}

export class ExtendedCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('extended', 'Extended Typographic Ramp', CHAR_SETS.extended);
  }
}

export class BlockCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('block', 'Unicode Block Shading Ramp', CHAR_SETS.block);
  }
}

export class BrailleCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('braille', 'Unicode Braille Patterns', CHAR_SETS.braille);
  }
}

export class MatrixCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('matrix', 'Matrix Digital Rain Ramp', CHAR_SETS.matrix);
  }
}

export class MinimalCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('minimal', 'Minimalist Ramp', CHAR_SETS.minimal);
  }
}

export class Video2CharsCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('video2chars', 'Video2Chars 83-Char Ramp', CHAR_SETS.video2chars);
  }
}

export class LettersCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('letters', 'Letters Alphabet Ramp (A-Z, a-z)', CHAR_SETS.letters);
  }
}

export class NumbersCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('numbers', 'Numeric Digits Ramp (0-9)', CHAR_SETS.numbers);
  }
}

export class SymbolsCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('symbols', 'Special Symbols & Operators', CHAR_SETS.symbols);
  }
}

export class AlphanumericCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('alphanumeric', 'Alphanumeric Matrix Code', CHAR_SETS.alphanumeric);
  }
}

export class BinaryCharEngine extends BaseCharacterSetEngine {
  constructor() {
    super('binary', 'Binary 0/1 Matrix', CHAR_SETS.binary);
  }
}

export class CharacterSetEngineRegistry {
  constructor() {
    this._engines = new Map();
    this.register(new StandardCharEngine());
    this.register(new ExtendedCharEngine());
    this.register(new BlockCharEngine());
    this.register(new BrailleCharEngine());
    this.register(new MatrixCharEngine());
    this.register(new MinimalCharEngine());
    this.register(new Video2CharsCharEngine());
    this.register(new LettersCharEngine());
    this.register(new NumbersCharEngine());
    this.register(new SymbolsCharEngine());
    this.register(new AlphanumericCharEngine());
    this.register(new BinaryCharEngine());
  }

  register(engine) {
    this._engines.set(engine.id, engine);
    return this;
  }

  get(idOrChars) {
    if (!idOrChars) return this._engines.get('standard');
    if (typeof idOrChars === 'string') {
      if (this._engines.has(idOrChars)) return this._engines.get(idOrChars);
      for (const eng of this._engines.values()) {
        if (eng.rawString === idOrChars) return eng;
      }
      return new BaseCharacterSetEngine('custom', 'Custom Character Set', idOrChars);
    }
    if (Array.isArray(idOrChars)) {
      return new BaseCharacterSetEngine('custom', 'Custom Character Set', idOrChars);
    }
    return this._engines.get('standard');
  }

  getAll() {
    return Array.from(this._engines.values());
  }
}

export const characterSetRegistry = new CharacterSetEngineRegistry();
export function getCharacterSetEngine(idOrChars) {
  return characterSetRegistry.get(idOrChars);
}

// ─── Mode Engines ───────────────────────────────────────────────────────────

export class BaseModeEngine {
  constructor(id, name, options = {}) {
    this.id = id;
    this.name = name;
    this.colorMode = options.colorMode || 'monochrome';
    this.defaultCharSet = options.defaultCharSet || 'standard';
    this.defaultMonoColor = options.defaultMonoColor || '#39ff52';
    this.defaultBgColor = options.defaultBgColor || '#0a0a0c';
    this.scanlinesSupported = options.scanlinesSupported ?? true;
    this.edgeDetectSupported = options.edgeDetectSupported ?? true;
    this.contrastMultiplier = options.contrastMultiplier ?? 1.0;
  }

  prepareConfig(userConfig = {}) {
    return {
      colorMode: userConfig.colorMode || this.colorMode,
      charSet: userConfig.charSet || this.defaultCharSet,
      monoColor: userConfig.monoColor || this.defaultMonoColor,
      bgColor: userConfig.bgColor || this.defaultBgColor,
      scanlines: userConfig.scanlines ?? false,
      edgeDetection: userConfig.edgeDetection ?? (userConfig.enableEdgeDetection ?? false),
      brightness: userConfig.brightness ?? 0,
      contrast: userConfig.contrast ?? 0,
      gamma: userConfig.gamma ?? 0,
      saturation: userConfig.saturation ?? 0,
      invertChars: Boolean(userConfig.invertChars),
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    };
  }

  getColorForPixel(r, g, b, lum, config = {}) {
    const mode = config.colorMode || this.colorMode;
    if (mode === 'monochrome') {
      return hexToRgbVec3(config.monoColor || this.defaultMonoColor);
    }
    if (mode === 'grayscale') {
      return [lum, lum, lum];
    }
    return [r / 255.0, g / 255.0, b / 255.0];
  }

  getShaderModeInt(config = {}) {
    const mode = config.colorMode || this.colorMode;
    switch (mode) {
      case 'monochrome': return 0;
      case 'grayscale':  return 1;
      case 'ansi16':     return 2;
      case 'ansi256':    return 3;
      default:           return 4; // TrueColor RGB
    }
  }
}

export class ClassicModeEngine extends BaseModeEngine {
  constructor() {
    super('classic', 'Classic CRT Monochrome', {
      colorMode: 'monochrome',
      defaultCharSet: 'standard',
      defaultMonoColor: '#39ff52',
      defaultBgColor: '#0a0a0c',
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      monoColor: userConfig.monoColor || '#39ff52',
      bgColor: userConfig.bgColor || '#0a0a0c',
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class MatrixModeEngine extends BaseModeEngine {
  constructor() {
    super('matrix', 'Matrix Digital Rain', {
      colorMode: 'monochrome',
      defaultCharSet: 'matrix',
      defaultMonoColor: '#00ff66',
      defaultBgColor: '#020b04',
      scanlinesSupported: true,
      edgeDetectSupported: true,
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      monoColor: userConfig.monoColor || '#00ff66',
      bgColor: userConfig.bgColor || '#020b04',
      contrast: userConfig.contrast ?? 30,
      brightness: userConfig.brightness ?? 10,
      scanlines: userConfig.scanlines ?? true,
      enableEdgeDetection: userConfig.enableEdgeDetection ?? true,
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class TrueColorModeEngine extends BaseModeEngine {
  constructor() {
    super('truecolor', 'TrueColor 24-Bit RGB', {
      colorMode: 'truecolor',
      defaultCharSet: 'extended',
      defaultBgColor: '#0a0a0c',
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      bgColor: userConfig.bgColor || '#0a0a0c',
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class BrailleModeEngine extends BaseModeEngine {
  constructor() {
    super('braille', 'Braille Sub-Dot Matrix', {
      colorMode: 'monochrome',
      defaultCharSet: 'braille',
      defaultMonoColor: '#ffffff',
      defaultBgColor: '#0a0a0c',
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      monoColor: userConfig.monoColor || '#ffffff',
      bgColor: userConfig.bgColor || '#0a0a0c',
      contrast: userConfig.contrast ?? 20,
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class BlocksModeEngine extends BaseModeEngine {
  constructor() {
    super('blocks', 'Unicode Shaded Blocks', {
      colorMode: 'truecolor',
      defaultCharSet: 'block',
      defaultBgColor: '#0a0a0c',
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      bgColor: userConfig.bgColor || '#0a0a0c',
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class Video2CharsModeEngine extends BaseModeEngine {
  constructor() {
    super('video2chars', 'Video2Chars Paper & Art Engine', {
      colorMode: 'truecolor',
      defaultCharSet: 'video2chars',
      defaultBgColor: '#ffffff',
      contrastMultiplier: 1.2,
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      bgColor: userConfig.bgColor || '#ffffff',
      contrast: userConfig.contrast ?? 20,
      brightness: userConfig.brightness ?? 5,
      saturation: userConfig.saturation ?? 10,
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class NegativeSpaceModeEngine extends BaseModeEngine {
  constructor() {
    super('negative_space', 'Negative Space Silhouette Engine', {
      colorMode: 'monochrome',
      defaultCharSet: 'letters',
      defaultBgColor: '#0a0a0c',
      defaultMonoColor: '#39ff52',
    });
  }

  prepareConfig(userConfig = {}) {
    return super.prepareConfig({
      bgColor: userConfig.bgColor || '#0a0a0c',
      monoColor: userConfig.monoColor || '#39ff52',
      renderMode: userConfig.renderMode || 'negative_space',
      contrast: userConfig.contrast ?? 15,
      brightness: userConfig.brightness ?? 5,
      ...userConfig,
      colorMode: userConfig.colorMode || this.colorMode,
    });
  }
}

export class ModeEngineRegistry {
  constructor() {
    this._engines = new Map();
    this.register(new ClassicModeEngine());
    this.register(new MatrixModeEngine());
    this.register(new TrueColorModeEngine());
    this.register(new BrailleModeEngine());
    this.register(new BlocksModeEngine());
    this.register(new Video2CharsModeEngine());
    this.register(new NegativeSpaceModeEngine());
  }

  register(engine) {
    this._engines.set(engine.id, engine);
    return this;
  }

  get(id) {
    if (!id) return this._engines.get('classic');
    const key = String(id).toLowerCase();
    if (this._engines.has(key)) return this._engines.get(key);
    if (key === 'mono' || key === 'monochrome' || key === 'grayscale') return this._engines.get('classic');
    if (key === 'rgb' || key === 'truecolor' || key === 'ansi16' || key === 'ansi256') return this._engines.get('truecolor');
    return this._engines.get('classic');
  }

  getAll() {
    return Array.from(this._engines.values());
  }
}

export const modeRegistry = new ModeEngineRegistry();
export function getModeEngine(id) {
  return modeRegistry.get(id);
}

// ─── AsciliEngine (GPU Vision Engine - Sub-1.5ms, 2M Chars @ 120 FPS) ────────

export class AsciliEngine {
  constructor() {
    this.modeRegistry    = new ModeEngineRegistry();
    this.charSetRegistry = new CharacterSetEngineRegistry();

    this._sampleCanvas  = document.createElement('canvas');
    this._sampleCtx     = this._sampleCanvas.getContext('2d', { willReadFrequently: true });
    this._atlas         = new AsciliGlyphAtlas();
    this._fgAtlas       = new AsciliGlyphAtlas();
    this._gpuCanvas     = document.createElement('canvas');
    this._gpuCanvas.width  = 640;
    this._gpuCanvas.height = 360;
    this.hardwareProfile = getGraphicsProfile();
    try {
      this._webgl = new AsciliWebGLRenderer(this._gpuCanvas);
      this._webgl.profile = this.hardwareProfile;
    } catch {
      this._webgl = null;
    }
    this._displayCtx    = null;
    this._canvas2d      = null;
    this._canvasWorker  = null;
    this._canvasWorkerFailed = false;
    this._currentTarget = null;

    this._lastCols      = 0;
    this._lastRows      = 0;
    this._lastConfig    = null;
    this._lastSource    = null;
    this._fallbackChars = new Uint8Array(0);
    this._fallbackColors = new Uint8Array(0);
    this._fallbackCapacity = 0;
    this._prevCharGrid = new Uint8Array(0);
  }

  get gpuCanvas() { return this._gpuCanvas; }

  getModeEngine(mode) {
    return this.modeRegistry.get(mode);
  }

  getCharSetEngine(charSet) {
    return this.charSetRegistry.get(charSet);
  }

  registerModeEngine(engine) {
    this.modeRegistry.register(engine);
    return this;
  }

  registerCharSetEngine(engine) {
    this.charSetRegistry.register(engine);
    return this;
  }

  renderFrame(videoEl, targetCanvas, config = {}) {
    if (!videoEl) return { rows: 0, cols: 0, chars: 0 };

    // Delegate mode-specific and character-set-specific preparation to dedicated engines
    const modeEngine = this.getModeEngine(config.mode || config.preset || config.colorMode || 'classic');
    const charSetEngine = this.getCharSetEngine(config.charSet || modeEngine.defaultCharSet);
    const preparedConfig = modeEngine.prepareConfig(config);

    const vw = videoEl.videoWidth  || videoEl.width  || 640;
    const vh = videoEl.videoHeight || videoEl.height || 480;
    const crop = computeCropBox(vw, vh, preparedConfig.aspectRatio);
    const cellRatio = (crop.sh / crop.sw) * 0.45;
    const requestedCols = Math.min(1000, Math.max(20, Math.round(preparedConfig.cols || 80)));
    const maxColsForSafeFrame = Math.floor(Math.sqrt(500_000 / Math.max(cellRatio, 0.01)));
    const cols = preparedConfig.cols ? Math.min(1000, Math.max(20, Math.round(preparedConfig.cols))) : Math.min(requestedCols, Math.max(20, maxColsForSafeFrame));

    const rows = preparedConfig.rows ?? Math.max(1, Math.round(cols * (crop.sh / crop.sw) * 0.45));
    const totalCells = rows * cols;

    this._lastCols   = cols;
    this._lastRows   = rows;
    this._lastConfig = { ...preparedConfig };
    this._lastSource = videoEl;

    this._atlas.update(charSetEngine.rawString);
    if (preparedConfig.fgCharSet) {
      const fgEngine = this.getCharSetEngine(preparedConfig.fgCharSet);
      this._fgAtlas.update(fgEngine.rawString);
      preparedConfig.fgAtlas = this._fgAtlas;
      preparedConfig.fgCharEngine = fgEngine;
    }

    if (targetCanvas instanceof HTMLCanvasElement) {
      if (targetCanvas.width <= 0 || targetCanvas.height <= 0) {
        return { rows, cols, chars: totalCells, rendered: false };
      }

      if (this._currentTarget !== targetCanvas) {
        this._currentTarget = targetCanvas;
        // Keep the visible canvas 2D-capable so a shader/context failure can
        // always fall back and screenshots/recordings see the finished frame.
        this._displayCtx = targetCanvas.getContext('2d', { alpha: false });
        if (!this._webgl) {
          try {
            this._webgl = new AsciliWebGLRenderer(this._gpuCanvas);
            this._webgl.profile = this.hardwareProfile;
          } catch {
            this._webgl = null;
          }
        }

        if (!this._webgl?.supported) this._webgl = null;
        if (!this._webgl) this._initFallbackRenderer(targetCanvas);
      }

      // Check if WebGL context needs recreation
      if (this._webgl && (!this._webgl.supported || this._webgl.gl?.isContextLost())) {
        const now = performance.now();
        if (!this._lastContextRetry || now - this._lastContextRetry > 2000) {
          this._lastContextRetry = now;
          try {
            this._gpuCanvas = document.createElement('canvas');
            this._gpuCanvas.width = targetCanvas.width;
            this._gpuCanvas.height = targetCanvas.height;
            this._webgl = new AsciliWebGLRenderer(this._gpuCanvas);
            this._webgl.profile = this.hardwareProfile;
          } catch {
            this._webgl = null;
          }
        }
      }

      // Prefer the GPU path; timer queries report GPU time asynchronously when supported.
      let rendered = false;
      if (this._webgl && this._webgl.supported) {
        if (this._gpuCanvas.width !== targetCanvas.width) this._gpuCanvas.width = targetCanvas.width;
        if (this._gpuCanvas.height !== targetCanvas.height) this._gpuCanvas.height = targetCanvas.height;
        try {
          rendered = this._webgl.renderDirect(videoEl, cols, rows, this._atlas, preparedConfig);
          if (rendered && this._displayCtx && targetCanvas.width > 0 && targetCanvas.height > 0) {
            this._displayCtx.drawImage(this._gpuCanvas, 0, 0, targetCanvas.width, targetCanvas.height);
          }
        } catch {
          rendered = false;
          if (this._webgl?.gl?.isContextLost()) {
            this._webgl.supported = false;
          }
        }
      }

      // Fallback path: engaged if WebGL failed or is unavailable on this device
      if (!rendered) {
        if (!preparedConfig.syncOnly && !this._canvasWorker && !this._canvas2d && totalCells <= 500_000) {
          this._initFallbackRenderer(targetCanvas);
        }
        if (!preparedConfig.syncOnly && this._canvasWorker && totalCells <= 500_000) {
          rendered = this._canvasWorker.render(videoEl, cols, rows, this._atlas, preparedConfig);
        }
        if (!rendered && this._canvasWorker?.failed) {
          this._canvasWorker.worker.terminate();
          this._canvasWorker = null;
          this._canvasWorkerFailed = true;
          this._initFallbackRenderer(targetCanvas);
        }
        if (!rendered) {
          if (!this._canvas2d || this._canvas2d.canvas !== targetCanvas) {
            try { this._canvas2d = new AsciliCanvas2DRenderer(targetCanvas); } catch { this._canvas2d = null; }
          }
          if (this._canvas2d) {
            this._renderFallback2D(videoEl, cols, rows, preparedConfig, modeEngine, charSetEngine);
            rendered = true;
          }
        }
      }

      if (!rendered) {
        return { rows, cols, chars: totalCells, rendered: false };
      }
    }

    return { rows, cols, chars: totalCells, rendered: true };
  }

  getPerformanceStats() {
    return {
      renderer: this._webgl?.supported ? 'webgl' : this._canvasWorker ? 'canvas-worker' : 'canvas-2d',
      gpuTimeMs: this._webgl?.gpuTimeMs ?? null,
      workerTimeMs: this._canvasWorker?.renderTimeMs ?? null,
    };
  }

  _initFallbackRenderer(targetCanvas) {
    if (this._canvasWorker || this._canvas2d) return;
    if (!this._canvasWorkerFailed && typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined' && typeof createImageBitmap === 'function') {
      try {
        this._canvasWorker = new AsciliCanvasWorkerRenderer(targetCanvas);
        if (this._canvasWorker.failed) {
          this._canvasWorker.worker.terminate();
          this._canvasWorker = null;
          this._canvasWorkerFailed = true;
        }
      } catch {
        this._canvasWorker = null;
        this._canvasWorkerFailed = true;
      }
    }
    if (!this._canvasWorker) {
      try { this._canvas2d = new AsciliCanvas2DRenderer(targetCanvas); }
      catch { this._canvas2d = null; }
    }
  }

  _renderFallback2D(videoEl, cols, rows, config, modeEngine, charSetEngine) {
    if (this._sampleCanvas.width !== cols || this._sampleCanvas.height !== rows) {
      this._sampleCanvas.width  = cols;
      this._sampleCanvas.height = rows;
    }
    const vw = videoEl.videoWidth  || videoEl.width  || 640;
    const vh = videoEl.videoHeight || videoEl.height || 480;
    const crop = computeCropBox(vw, vh, config.aspectRatio);

    const mode = modeEngine || this.getModeEngine(config.mode || config.preset || config.colorMode || 'classic');
    const charEngine = charSetEngine || this.getCharSetEngine(config.charSet || mode.defaultCharSet);

    this._sampleCtx.save();
    if (config.mirror) {
      this._sampleCtx.translate(cols, 0);
      this._sampleCtx.scale(-1, 1);
    }
    this._sampleCtx.drawImage(videoEl, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, cols, rows);
    this._sampleCtx.restore();

    let imgData;
    try { imgData = this._sampleCtx.getImageData(0, 0, cols, rows).data; } catch { return; }

    const cells = cols * rows;
    if (cells > this._fallbackCapacity) {
      this._fallbackChars = new Uint8Array(cells);
      this._fallbackCapacity = cells;
    }
    const isMono = config.colorMode === 'monochrome';
    if (!isMono && this._fallbackColors.length < cells * 3) {
      this._fallbackColors = new Uint8Array(cells * 3);
    }
    const charGrid = this._fallbackChars;
    const colorGrid = this._fallbackColors;
    const n = this._atlas.charCount;

    const doAdj = config.brightness || config.contrast || config.gamma || config.saturation;

    const lumGrid = new Float32Array(cells);
    for (let i = 0; i < cells; i++) {
      const p4 = i * 4;
      let r = imgData[p4], g = imgData[p4+1], b = imgData[p4+2];
      if (doAdj) {
        [r, g, b] = adjustPixel(r, g, b, config.brightness || 0, config.contrast || 0, config.gamma || 0, config.saturation || 0);
      }
      lumGrid[i] = (0.299*r + 0.587*g + 0.114*b) / 255.0;
      if (!isMono) {
        const p3 = i * 3;
        if (config.colorMode === 'grayscale') {
          const lVal = Math.round(lumGrid[i] * 255);
          colorGrid[p3]     = lVal;
          colorGrid[p3 + 1] = lVal;
          colorGrid[p3 + 2] = lVal;
        } else if (config.colorMode === 'ansi16') {
          const [cr, cg, cb] = quantizeAnsi16(r, g, b);
          colorGrid[p3]     = cr;
          colorGrid[p3 + 1] = cg;
          colorGrid[p3 + 2] = cb;
        } else if (config.colorMode === 'ansi256') {
          const [cr, cg, cb] = quantizeAnsi256(r, g, b);
          colorGrid[p3]     = cr;
          colorGrid[p3 + 1] = cg;
          colorGrid[p3 + 2] = cb;
        } else {
          colorGrid[p3]     = r;
          colorGrid[p3 + 1] = g;
          colorGrid[p3 + 2] = b;
        }
      }
    }

    if (config.dithering && config.dithering !== 'none') {
      applyDithering(lumGrid, cols, rows, n, config.dithering);
    }

    const enableEdge = config.enableEdgeDetection ?? true;
    const edgeThreshold = config.edgeThreshold ?? 0.16;
    const edgeThresholdSq = edgeThreshold * edgeThreshold;
    const allowEdge = enableEdge && n >= 5 && rows > 2 && cols > 2;

    for (let r = 0; r < rows; r++) {
      const rOffset = r * cols;
      for (let c = 0; c < cols; c++) {
        const idx = rOffset + c;
        let charToUse = null;

        if (allowEdge && r > 0 && r < rows - 1 && c > 0 && c < cols - 1) {
          const gx = (lumGrid[rOffset + (c + 1)] - lumGrid[rOffset + (c - 1)]) * 0.5;
          const gy = (lumGrid[(r + 1) * cols + c] - lumGrid[(r - 1) * cols + c]) * 0.5;
          const magSq = gx * gx + gy * gy;

          if (magSq >= edgeThresholdSq) {
            charToUse = charEngine.getEdgeChar(gx, gy);
          }
        }

        if (charToUse) {
          charGrid[idx] = charToUse;
        } else {
          charGrid[idx] = charEngine.getCharIndexForLuminance(lumGrid[idx], config.invertChars);
        }

        // Negative Space / Segmentation masking in 2D fallback
        const rMode = config.renderMode || config.negSpaceMode || 'none';
        if (config.detector && config.detector.enabled && rMode !== 'none') {
          const uNorm = (c + 0.5) / cols;
          const vNorm = (r + 0.5) / rows;
          const maskVal = config.detector.sampleMaskAt(uNorm, vNorm);
          const thresh = config.maskThreshold ?? config.negSpaceSensitivity ?? 0.5;
          const isSubject = maskVal >= thresh;

          if (rMode === 'negative_space') {
            if (isSubject) charGrid[idx] = 0; // Space / empty glyph
          } else if (rMode === 'inverted_ascii') {
            if (!isSubject) charGrid[idx] = 0; // Space / empty glyph
          } else if (rMode === 'hybrid' && config.fgCharEngine && isSubject) {
            charGrid[idx] = config.fgCharEngine.getCharIndexForLuminance(lumGrid[idx], config.invertChars);
          }
        }
      }
    }

    if (config.temporalStability !== false) {
      if (this._prevCharGrid.length !== cells) {
        this._prevCharGrid = new Uint8Array(cells);
      }
      for (let i = 0; i < cells; i++) {
        const prev = this._prevCharGrid[i];
        const current = charGrid[i];
        if (typeof current === 'number' && typeof prev === 'number' && Math.abs(current - prev) <= 2) {
          charGrid[i] = Math.round((current + prev) * 0.5);
        }
      }
      this._prevCharGrid.set(charGrid);
    }

    if (!this._canvas2d || this._canvas2d.canvas !== this._currentTarget) {
      try { this._canvas2d = new AsciliCanvas2DRenderer(this._currentTarget); } catch { this._canvas2d = null; }
    }
    if (this._canvas2d) {
      this._canvas2d.render(cols, rows, charGrid, colorGrid, this._atlas, isMono, config.monoColor || mode.defaultMonoColor, config.fontSize || 10, config.bgColor || mode.defaultBgColor);
    }
  }

  async exportPlainTextAsync(onProgress) {
    const cols = this._lastCols;
    const rows = this._lastRows;
    const src  = this._lastSource;
    const cfg  = this._lastConfig || {};
    if (!cols || !rows || !src) return '';

    const mode = this.getModeEngine(cfg.mode || cfg.preset || cfg.colorMode || 'classic');
    const charEngine = this.getCharSetEngine(cfg.charSet || mode.defaultCharSet);

    const off = document.createElement('canvas');
    off.width  = cols;
    off.height = rows;
    const octx = off.getContext('2d', { willReadFrequently: true });
    const vw = src.videoWidth  || src.width  || 640;
    const vh = src.videoHeight || src.height || 480;
    const crop = computeCropBox(vw, vh, cfg.aspectRatio);

    octx.save();
    if (cfg.mirror) {
      octx.translate(cols, 0);
      octx.scale(-1, 1);
    }
    octx.drawImage(src, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, cols, rows);
    octx.restore();

    const imgData = octx.getImageData(0, 0, cols, rows).data;
    const nChars = charEngine.length;
    const invert = cfg.invertChars || false;

    const cells = rows * cols;
    const lumGrid = new Float32Array(cells);
    for (let i = 0; i < cells; i++) {
      const p4 = i * 4;
      lumGrid[i] = (0.299 * imgData[p4] + 0.587 * imgData[p4 + 1] + 0.114 * imgData[p4 + 2]) / 255.0;
    }

    if (cfg.dithering && cfg.dithering !== 'none') {
      applyDithering(lumGrid, cols, rows, nChars, cfg.dithering);
    }

    const lines = [];
    const chunkSize = 200;

    for (let r = 0; r < rows; r += chunkSize) {
      const endR = Math.min(rows, r + chunkSize);
      for (let cr = r; cr < endR; cr++) {
        let line = '';
        const offset = cr * cols;
        for (let c = 0; c < cols; c++) {
          line += charEngine.getCharForLuminance(lumGrid[offset + c], invert);
        }
        lines.push(line);
      }
      onProgress?.(Math.round((endR / rows) * 100));
      if (endR < rows) await new Promise(res => setTimeout(res, 0));
    }

    return lines.join('\n');
  }

  async exportStyledHtmlAsync(options = {}, onProgress) {
    const cols = this._lastCols;
    const rows = this._lastRows;
    const src  = this._lastSource;
    const cfg  = this._lastConfig || {};
    if (!cols || !rows || !src) return '';

    const mode = this.getModeEngine(cfg.mode || cfg.preset || cfg.colorMode || 'classic');
    const charEngine = this.getCharSetEngine(cfg.charSet || mode.defaultCharSet);

    const off = document.createElement('canvas');
    off.width  = cols;
    off.height = rows;
    const octx = off.getContext('2d', { willReadFrequently: true });
    octx.drawImage(src, 0, 0, cols, rows);
    const imgData = octx.getImageData(0, 0, cols, rows).data;

    const invert    = cfg.invertChars || false;
    const isMono    = (cfg.colorMode || mode.colorMode) === 'monochrome';
    const monoColor = options.monoColor || cfg.monoColor || mode.defaultMonoColor;
    const fontSize  = options.fontSize  || cfg.fontSize || 10;

    const htmlLines = [];
    const chunkSize = 150;

    for (let r = 0; r < rows; r += chunkSize) {
      const endR = Math.min(rows, r + chunkSize);
      for (let cr = r; cr < endR; cr++) {
        let line = '';
        const offset = cr * cols;
        if (isMono) {
          for (let c = 0; c < cols; c++) {
            const p4 = (offset + c) * 4;
            const lum = (0.299 * imgData[p4] + 0.587 * imgData[p4 + 1] + 0.114 * imgData[p4 + 2]) / 255.0;
            line += esc(charEngine.getCharForLuminance(lum, invert));
          }
        } else {
          let currColor = null;
          let currRun   = '';
          for (let c = 0; c < cols; c++) {
            const p4 = (offset + c) * 4;
            let red = imgData[p4], green = imgData[p4+1], blue = imgData[p4+2];
            const lum = (0.299 * red + 0.587 * green + 0.114 * blue) / 255.0;
            const ch = esc(charEngine.getCharForLuminance(lum, invert));
            if (cfg.colorMode === 'grayscale') {
              const gray = Math.round(lum * 255);
              red = gray; green = gray; blue = gray;
            } else if (cfg.colorMode === 'ansi16') {
              const [cr, cg, cb] = quantizeAnsi16(red, green, blue);
              red = cr; green = cg; blue = cb;
            } else if (cfg.colorMode === 'ansi256') {
              const [cr, cg, cb] = quantizeAnsi256(red, green, blue);
              red = cr; green = cg; blue = cb;
            }
            const colorKey = `${red},${green},${blue}`;

            if (colorKey === currColor) {
              currRun += ch;
            } else {
              if (currColor !== null) {
                line += `<span style="color:rgb(${currColor})">${currRun}</span>`;
              }
              currColor = colorKey;
              currRun   = ch;
            }
          }
          if (currColor !== null) {
            line += `<span style="color:rgb(${currColor})">${currRun}</span>`;
          }
        }
        htmlLines.push(line);
      }
      onProgress?.(Math.round((endR / rows) * 100));
      if (endR < rows) await new Promise(res => setTimeout(res, 0));
    }

    const bg    = cfg.bgColor || mode.defaultBgColor || '#000';
    const color = isMono ? monoColor : '#fff';
    const body  = htmlLines.join('\n');
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<title>ASCILI Export</title>
<style>
body{margin:0;background:${bg};padding:8px}
pre{font-family:'Courier New',monospace;font-size:${fontSize}px;line-height:1;color:${color};white-space:pre;overflow:auto}
</style>
</head>
<body><pre>${body}</pre></body>
</html>`;
  }

  getPlainText() {
    const cols = this._lastCols;
    const rows = this._lastRows;
    const src  = this._lastSource;
    const cfg  = this._lastConfig || {};
    if (!cols || !rows || !src) return '';

    const mode = this.getModeEngine(cfg.mode || cfg.preset || cfg.colorMode || 'classic');
    const charEngine = this.getCharSetEngine(cfg.charSet || mode.defaultCharSet);

    const off = document.createElement('canvas');
    off.width  = cols;
    off.height = rows;
    const octx = off.getContext('2d', { willReadFrequently: true });
    octx.drawImage(src, 0, 0, cols, rows);
    const imgData = octx.getImageData(0, 0, cols, rows).data;

    const invert = cfg.invertChars || false;

    const lines = [];
    for (let r = 0; r < rows; r++) {
      let line = '';
      const offset = r * cols;
      for (let c = 0; c < cols; c++) {
        const p4 = (offset + c) * 4;
        const lum = (0.299 * imgData[p4] + 0.587 * imgData[p4 + 1] + 0.114 * imgData[p4 + 2]) / 255.0;
        line += charEngine.getCharForLuminance(lum, invert);
      }
      lines.push(line);
    }
    return lines.join('\n');
  }

  getStyledHtml(options = {}) {
    const text = this.getPlainText();
    const cfg = this._lastConfig || {};
    const mode = this.getModeEngine(cfg.mode || cfg.preset || cfg.colorMode || 'classic');
    const bg   = cfg.bgColor || mode.defaultBgColor || '#000';
    const color = (options.colorMode || cfg.colorMode || mode.colorMode) === 'monochrome'
      ? (options.monoColor || cfg.monoColor || mode.defaultMonoColor)
      : '#fff';
    const fontSize = options.fontSize || cfg.fontSize || 10;
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<title>ASCILI Export</title>
<style>
body{margin:0;background:${bg};padding:8px}
pre{font-family:'Courier New',monospace;font-size:${fontSize}px;line-height:1;color:${color};white-space:pre;overflow:auto}
</style>
</head>
<body><pre>${text}</pre></body>
</html>`;
  }

  reset() {
    this._lastCols = 0;
    this._lastRows = 0;
    this._lastConfig = null;
    this._lastSource = null;
    this._prevCharGrid = new Uint8Array(0);
    this._canvasWorker?.reset();
  }
}

// Backward compatibility alias for existing imports that may call this symbol.
export const AsciliEngineLegacy = AsciliEngine;

// NOTE: The browser-side engine already ships a WebGL fast path and a 2D fallback.
// These runtime profile checks keep the renderer stable across low-end devices and
// reduce visual flicker without sacrificing responsiveness.
